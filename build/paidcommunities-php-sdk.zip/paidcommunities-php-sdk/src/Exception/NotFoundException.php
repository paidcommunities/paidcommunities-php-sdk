<?php

namespace PaidCommunities\Exception;

class NotFoundException extends ApiErrorException {

}