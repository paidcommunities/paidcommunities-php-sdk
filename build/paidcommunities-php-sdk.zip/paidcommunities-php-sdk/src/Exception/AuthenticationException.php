<?php

namespace PaidCommunities\Exception;

class AuthenticationException extends ApiErrorException {

}