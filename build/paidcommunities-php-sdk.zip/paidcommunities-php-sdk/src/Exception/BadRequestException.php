<?php

namespace PaidCommunities\Exception;

class BadRequestException extends ApiErrorException {

}