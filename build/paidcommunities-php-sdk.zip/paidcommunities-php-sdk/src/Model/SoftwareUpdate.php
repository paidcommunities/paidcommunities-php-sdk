<?php

namespace PaidCommunities\Model;

/**
 * @property bool $update
 * @property string $version
 * @property string $package
 */
class SoftwareUpdate extends AbstractModel {

}