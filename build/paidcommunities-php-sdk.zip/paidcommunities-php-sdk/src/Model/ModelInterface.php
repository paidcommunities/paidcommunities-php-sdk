<?php

namespace PaidCommunities\Model;

interface ModelInterface {

}