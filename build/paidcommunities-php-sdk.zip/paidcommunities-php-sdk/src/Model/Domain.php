<?php

namespace PaidCommunities\Model;

/**
 * @property string $id;
 * @property string $domain
 * @property string $createdAt
 */
class Domain extends AbstractModel {

}